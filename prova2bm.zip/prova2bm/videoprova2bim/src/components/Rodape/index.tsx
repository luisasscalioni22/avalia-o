import React from "react";
import * as S from "./styles";

const Rodape = () => {
  return <S.Rodape>2022 - Todos os direitos reservados.</S.Rodape>;
};

export default Rodape;
