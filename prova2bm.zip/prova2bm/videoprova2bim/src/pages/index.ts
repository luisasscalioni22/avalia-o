
export { default as LayoutPage } from "./Layout"
export { default as HomePage } from "./Home"
export { default as PedidosPage } from "./Pedidos"

