const dados = [
  {
    id: 1,
    nome: "Lázaro",
    data: "27/04/2022 10:08:00",
    problema: "Falta Internet",
    descricao: "O computador não está conectado a internet. Estou com a fatura em dia e já desliguei o cabo de energia algumas vezes para verificar se volta.",
  },
  {
    id: 2,
    nome: "Lázaro",
    data: "27/04/2022 10:08:00",
    problema: "Falta Internet",
    descricao: "O computador não está conectado a internet. Estou com a fatura em dia e já desliguei o cabo de energia algumas vezes para verificar se volta.",
  },
  {
    id: 3,
    nome: "Lázaro",
    data: "27/04/2022 10:08:00",
    problema: "Falta Internet",
    descricao: "O computador não está conectado a internet. Estou com a fatura em dia e já desliguei o cabo de energia algumas vezes para verificar se volta.",
  },

]

export default dados