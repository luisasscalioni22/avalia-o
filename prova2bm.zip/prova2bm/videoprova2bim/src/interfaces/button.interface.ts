export interface IButton {
  children?: React.ReactNode
}
