export interface ICard {
  dados: {
    id: number,
    nome: string,
    data: string,
    problema: string,
    descricao: string,
  }
}
